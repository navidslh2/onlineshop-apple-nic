"use client";
import { headerData } from "@/lib/data";

import Link from "next/link";
import { usePathname } from "next/navigation";
import React from "react";

const HeaderMenu = () => {
  const pathName = usePathname();
  return (

      <ul className="hidden lg:flex text-gray-300/90 text-[13px] xl:gap-10 gap-5 ">
        {headerData.map((item,index) => (
          <li key={index}>
            <Link
              href={item.href}
              className={`group hover:text-white hoverEffect relative ${
                pathName === item.href ? "text-white" : null
              }`}
            >
              {item.title}
              <span className="hidden group-hover:block absolute bottom-[-30px] left-1/2 bg-white text-black p-1 whitespace-nowrap capitalize hoverEffect rounded-xs">
                {item.tooltip}
              </span>
            </Link>
          </li>
        ))}
      
      </ul>
  );
};

export default HeaderMenu;
